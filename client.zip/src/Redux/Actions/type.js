export const LoadTableSuccess = "LoadTableSuccess";
export const LoadTableFail = "LoadTableFail";
export const LoadFormSuccess = "LoadFormSuccess";
export const LoadFormFail = "LoadFormFail";
export const LoadUpdateSuccess = "LoadUpdateSuccess";
export const LoadUpadteFail = "LoadUpadteFail";
export const CreateDataSucess = "CreateDataSucess";
export const CreateDataFail = "CreateDataFail";
